package Game;

public class ElfInimigo extends Inimigo{

	public ElfInimigo(int vida) {
		super(vida);
	}
	
}
