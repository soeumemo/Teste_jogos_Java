package Game;

public class Player {

	public int vida = 10;
	public String nome = "Guilherme";
	
	public void perderVida() {
		vida-=1;
	}
	
	public void ganharVida() {
		vida+=1;
	}
	
}
